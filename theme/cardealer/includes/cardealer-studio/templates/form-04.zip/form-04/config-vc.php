<?php
/**
 *Form 04
 *
 * @package Cardealer
 */

return array(
	'name'              => esc_html__( 'Form 04', 'cardealer' ),
	'template_category' => esc_html__( 'Form', 'cardealer' ),
	'disabled'          => true, // Disable it to not show in the default tab.
	'content'           => '<<<CONTENT
<p>[vc_row full_width="stretch_row" cd_bg_type="row-background-dark" cd_overlay_opacity="60" cd_enable_overlay="true" css=".vc_custom_1625577048232{padding-top: 80px !important;padding-bottom: 80px !important;background-image: url(https://sampledata.potenzaglobalsolutions.com/cardealer/wp-content/uploads/2021/07/placeholder_1920x800.jpg?id=10874) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}" cd_overlay_color="#0c0c0c"][vc_column][vc_row_inner][vc_column_inner][cd_section_title heading_tag="h1" title_align="text-center" hide_seperator="true" style="style_1" section_title="SCHEDULE YOUR SERVICE" section_sub_title="Make Appointment"][/cd_section_title][/vc_column_inner][/vc_row_inner][vc_row_inner][vc_column_inner][contact-form-7 id="38"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]</p>


















CONTENT',
);
